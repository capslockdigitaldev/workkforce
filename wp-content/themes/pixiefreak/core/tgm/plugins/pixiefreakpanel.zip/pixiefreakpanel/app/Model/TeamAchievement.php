<?php

namespace PixieFreakPanel\Model;

use FusionFramework\Database\ORM;

class TeamAchievement extends ORM
{
    /**
     * @var string $table
     */
    protected $table = 'team_achievement';
}