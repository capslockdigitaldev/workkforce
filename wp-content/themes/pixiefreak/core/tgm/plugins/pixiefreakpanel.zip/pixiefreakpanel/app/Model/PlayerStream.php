<?php

namespace PixieFreakPanel\Model;

use FusionFramework\Database\ORM;

class PlayerStream extends ORM
{
    /**
     * @var string $table
     */
    protected $table = 'player_stream';
}