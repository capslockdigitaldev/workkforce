<?php

namespace PixieFreakPanel\Model;

use FusionFramework\Database\ORM;

class AboutStaff extends ORM
{
    /**
     * @var string $table
     */
    protected $table = 'about_staff';
}