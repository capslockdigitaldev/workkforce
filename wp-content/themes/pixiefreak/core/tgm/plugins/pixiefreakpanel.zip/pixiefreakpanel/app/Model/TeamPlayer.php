<?php

namespace PixieFreakPanel\Model;

use FusionFramework\Database\ORM;

class TeamPlayer extends ORM
{
    /**
     * @var string $table
     */
    protected $table = 'team_player';
}