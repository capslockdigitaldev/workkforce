<?php

namespace PixieFreakPanel\Model;

use FusionFramework\Database\ORM;

class GlobalSettings extends ORM
{
    /**
     * @var string $table
     */
    protected $table = 'global_settings';
}